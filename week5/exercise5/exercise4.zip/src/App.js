import React, { Component, useState } from "react";
import "./App.css";

class ParentButton extends Component {
  state ={
    count: 0
  }
  // handleCallback = (NewValue) => {
  //   this.setState({msg: NewValue})
  // }
  

  
  render() {
    const {count} =this.state;
    function handleCallback(value) {
      if(count === 0 && value === -1){
        return alert("Cannot unvote")
      }
      else if(count === 10 && value === 1){
        return alert("Cannot Vote more")
      }
      else {
        this.setState({msg: count + value})
        
      }
    }

    function msgChange (count) {
      if (count === 0) {
        return 'MIN';
      } else if (count === 10) {
        return 'MAX';
      }
      return count;
    }

    return (
      <div className="vote_container">
        <ChildButton name="Click to Vote" parentCallback={handleCallback} type = "+"/>
        <div className="result">{msgChange(count)}</div>
        <ChildButton name="Click to UnVote" parentCallback={handleCallback} type = "-"/>
      </div>
    );
  }
}
class ChildButton extends Component {

  render() {
    function check () {
      if (this.props.value === '+') {
        this.props.callBack(1);
      } else if (this.props.value === '-') {
        this.props.callBack(-1);
      }
    }
    return (

      <button onClick={() => check()}>{this.props.name}</button>
    );
  }
}

class Box extends Component {
  
  render() {
    return (
      <div className="box_container">
        <div className="data_container">
          <div>
            <h2>{this.props.type}</h2>
            <h4>{this.props.title}</h4>
            <p>{this.props.data}</p>
          </div>
          <img src={this.props.img} alt=""></img>
          <div className="btn_container"></div>
        </div>
        <div >
          <ParentButton/>
        </div>
      </div>
    );
  }
}

function App() {

  return (
    
    <div className="bg">
      <h1>โหวตอาหาร</h1>
      <Box
        type="อาหารคาว"
        title="Salmon"
        data="ปลาเป็นสุดยอดในด้านคุณค่าทางอาหารและคุณประโยชน์ต่อสุขภาพปลาได้ชื่อว่าเป็นโปรตีนย่อยง่ายมากๆอยู่แล้ว โดยเฉพาะปลาแซลมอนที่อุดมไปด้วยกรดไขมันโอเมก้า-3 (Omega- 3 fatty acid) ช่วยบำรุงสมองและระบบเลือดแถมยังป้องกันโรคต่างๆอีกมากมาย และยังเป็นแหล่งโปรตีนสูง เต็มไปด้วย วิตามินบี12 สรรพคุณสุดยอดไม่พอ รสชาติยังอร่อยอีกด้วย นั่นทำให้ปลาแซลมอนเป็นที่นิยมมากในบ้านเรา หาก็ง่าย มีทั้งในซูเปอร์มาร์เกตและในตลาดสด เราชอบปลาแซลมอนทั้งแบบทำสุกและกินดิบแบบซูชิหรือซาชิมิ ด้วยความรักพี่เสียดายน้องจึงขอนำเสนอปลาแซลมอนในแบบกึ่งสุกกึ่งดิบ คือ นำปลาไปดาดในกระทะให้สุกแค่รอบนอกโดยที่เนื้อข้างในยังดิบอยู่ กินกับข้าวญี่ปุ่นร้อนๆ ราดด้วยซอสมิโสะแบบฝรั่ง รสเข้มกลมกล่อม รับรองว่าจะติดใจแน่นอน "
        img="https://i.pinimg.com/564x/fc/9f/cb/fc9fcbc444dfe4dd77888605bad73976.jpg"
      />

      <Box
        type="อาหารหวาน"
        title="Pudding"
        data="พุดดิ้ง (Pudding) เป็นอาหารที่จัดอยู่ในพวกขนม (Dessert) หรือจานของหวานในสหรัฐอเมริกา พุดดิ้งมักจะหมายถึงขนมประเภททำจากไข่ไก่ที่ออกมาในรูปคล้ายสังขยา (Custard) มีส่วนผสมของนม น้ำตาล แป้งอเนกประสงค์ และน้ำมันพืชหรือเนย ที่ทำให้สุกแบบคน หรือกวนเข้าด้วยกัน โดยใช้ความร้อนย่างอ่อนจนสุก การคนหรือกวนตลอดเวลา จะทำให้ไข่ไม่สุกแบบเป็นลิ่มทำให้ไม่น่ากิน หากคนตลอดเวลา เมื่อสุกแล้วจะมีลักษณะเป็นครีม อาจมีการแต่งสีและกลิ่น เช่น วานิลา เติมผลไม้ เช่น สตรอเบอรี่ กล้วย สับปะรด หรือข้าวสุก (Rice pudding) ประสมลงไป"
        img="https://i.pinimg.com/564x/b9/a2/74/b9a2747a335a6584674ec136d8a304f9.jpg"
      />
    </div>
  );
}

export default App;
